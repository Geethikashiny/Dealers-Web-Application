<?php
	require '../config/config.php';
	if(empty($_SESSION['username']))
		header('Location: login.php');	

		try {
			if($_SESSION['role'] == 'dealer'){
				$stmt = $connect->prepare("SELECT * FROM users WHERE role = 'driver' ");
				$stmt->execute();
				$data = $stmt->fetchAll (PDO::FETCH_ASSOC);
			

				
			}

		}catch(PDOException $e) {
			$errMsg = $e->getMessage();
		}	
		// print_r($data1);	
		// echo "<br><br><br>";
		// print_r($data2);
		// echo "<br><br><br>";	
		// print_r($data);	
?>
<?php include '../include/header.php';?>

	<!-- Header nav -->	
	<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color:#212529;" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="../index.php">Home</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav text-uppercase ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="#"><?php echo $_SESSION['fullname']; ?> <?php if($_SESSION['role'] == 'dealer'){ echo "(dealer)"; } ?></a>
            </li>
            <li class="nav-item">
              <a href="../auth/logout.php" class="nav-link">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	<!-- end header nav -->
	<section style="padding-left:0px;">
		<?php include '../include/side-nav.php';?>
	</section>

<section class="wrapper" style="margin-left: 16%;margin-top: -23%;">

	<div class="container">
		<div class="row">
			<div class="col-12">
			<?php
				if(isset($errMsg)){
					echo '<div style="color:#FF0000;text-align:center;font-size:17px;">'.$errMsg.'</div>';
				}
				if(count($data) !== 0){
                echo "<h2 class='text-center'>LIST OF DRIVERS</h2>";
              }
			?>
			<h2>List of Drivers Details</h2>
				<?php 
                foreach ($data as $key => $value) {   
                  
		
					echo '<div class= "card  card bg-light mb-3 card border-success mb-3 "  style="padding:1%;">          
                        <div class="card-block">';
                          // echo '<a class="btn btn-warning float-right" href="update.php?id='.$value['id'].'&act=';if(isset($value['ap_number_of_plats'])){ echo "ap"; }else{ echo "indi"; } echo '">Edit</a>';
                       
						                     
                               
					
						 
						
						echo '<div class="row">
						  <div class="col-5">
                            <h3 >DRIVER DETAILS</h3>';
                              
							  echo '<p><b>Driver Name: </b>'.$value['fullname'].'</p>';
                              echo '<p><b>Mobile Number: </b>'.$value['mobile'].'</p>';
                           
                              // echo '<p><b>Country: </b>'.$value['country'].'<b> State: </b>'.$value['state'].'<b> City: </b>'.$value['city'].'</p>';
                               echo '<p><b>Route 1  [From] :  </b>'.$value['place1_from'].'</p>';
							  
							  echo '<p><b>Route 1   [TO] : </b>'.$value['place1_to'].'</p>';
							  
							  echo '<p><b>Route 2  [From] :  </b>'.$value['place2_from'].'</p>';
							  
							  echo '<p><b>Route 2  [TO] : </b>'.$value['place2_to'].'</p>';
							  
							  echo '<p><b>Route 3  [From] : </b>'.$value['place3_from'].'</p>';
							  
							  echo '<p><b>Route 3   [TO] : </b>'.$value['place3_to'].'</p>';
                              echo '<p><b>Truck Capacity: </b>'.$value['truck_cap'].'</p>';
						 echo '</div>
						 </div>
                        </div>
						</div>';
							
                   
                       
						              
                     
				  
				}
              ?>       
			</div>
		</div>
	</div>	
</section>

<?php include '../include/footer.php';?>