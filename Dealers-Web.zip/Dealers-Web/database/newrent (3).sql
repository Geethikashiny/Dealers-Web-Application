-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2022 at 06:59 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newrent`
--

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `name` varchar(20) NOT NULL,
  `msg` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`name`, `msg`) VALUES
('suma', 'Kiran'),
('Navya', 'Akhila');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `Age` int(10) UNSIGNED NOT NULL,
  `material` varchar(200) CHARACTER SET ascii DEFAULT NULL,
  `quantity` int(200) DEFAULT NULL,
  `city` varchar(20) CHARACTER SET armscii8 DEFAULT NULL,
  `state` varchar(20) CHARACTER SET armscii8 DEFAULT NULL,
  `truck_no` int(10) DEFAULT NULL,
  `truck_cap` int(10) DEFAULT NULL,
  `transporter_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `experience` int(100) DEFAULT NULL,
  `place1_from` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `place1_to` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `place2_from` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place2_to` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place3_from` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place3_to` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `mobile`, `username`, `email`, `password`, `role`, `Age`, `material`, `quantity`, `city`, `state`, `truck_no`, `truck_cap`, `transporter_name`, `experience`, `place1_from`, `place1_to`, `place2_from`, `place2_to`, `place3_from`, `place3_to`) VALUES
(1, 'Shiny', '9879879787', 'shiny', 'admin1mres@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'dealer', 25, 'Vegetables', 100, 'Vizag', 'Ap', 0, 0, '', 0, '', '', '', '', '', ''),
(14, 'Kiran Kumar', '7848412165', 'Kiran', 'kiran45@gmail.com', 'b1a5b64256e27fa5ae76d62b95209ab3', 'driver', 40, '', 0, '', '', 25, 15, 'Mani', 2, 'vizag', 'vijayawada', 'vizag', 'kakinada', 'nellore', 'kurnool'),
(13, 'Dimpu', '7845621112', 'dimpu', 'priya123@gmail.com', '48467d2cc726e8847fbc51f5b0bdc1d1', 'driver', 25, '', 0, '', '', 15, 102, 'prajna', 2, 'Hyderabad', 'Tanuku', 'Mumbai', 'Bangalore', 'Guntoor', 'kurnool'),
(17, 'suma', '0123456789', 'suma\r\n', 'abc@gmail.com', '900150983cd24fb0d6963f7d28e17f72', 'dealer', 22, 'books', 20, 'Kakinada', 'ap', 0, 0, '', NULL, NULL, '', '', '', '', ''),
(18, 'Navya', '90324545102', 'abcd', 'd@gmail.com', 'e2fc714c4727ee9395f324cd2e7f331f', 'dealer', 21, 'Wood', 150, 'Vizag', 'ap', 0, 0, '', NULL, NULL, '', '', '', '', ''),
(19, 'sushma', '1234568799', 'abcde', 'abcde@gmail.com', 'ab56b4d92b40713acc5af89985d4b786', 'driver', 21, '', 0, '', '', 4, 20, 'kiran', 5, 'Vizag', 'tanuku', 'vizag', 'nellore', 'chittor', 'kurnool'),
(20, 'Akhila', '8686877861', 'akhi', 'akhi@gmail.com', 'ca52febd8be7c4480ae90cdae8438a03', 'driver', 25, '', 0, '', '', 45, 100, 'kiran', 1, 'vizag', 'Kurnool', 'Nellore', 'Ongole', 'Tanuku', 'kurnool'),
(21, 'Priya', '7845621512', 'Priya1', 'priya1234@gmail.com', '48467d2cc726e8847fbc51f5b0bdc1d1', 'driver', 20, '', 0, '', '', 23, 101, 'Kumar', 2, 'Kurnool', 'Vizag', 'Palakol', 'kakinada', 'Guntoor', 'Ongole');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_mobile_unique` (`mobile`),
  ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
