<?php
	require '../config/config.php';

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require 'PHPMailer/src/Exception.php';
	require 'PHPMailer/src/PHPMailer.php';
	require 'PHPMailer/src/SMTP.php';

	if(isset($_POST['register'])) {
		$errMsg = '';

		// Get data from FROM
		$username = $_POST['username'];
		$mobile = $_POST['mobile'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$fullname = $_POST['fullname'];
		$role = $_POST['role'];
	    $Age = $_POST['Age'];
		$material = $_POST['material'];
		$quantity = $_POST['quantity'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$truck_no = $_POST['truck_no'];
		$truck_cap = $_POST['truck_cap'];
		$transporter_name = $_POST['transporter_name'];
		$experience = $_POST['experience'];
		$place1_from = $_POST['place1_from'];
		$place1_to = $_POST['place1_to'];
		$place2_from = $_POST['place2_from'];
		$place2_to = $_POST['place2_to'];
		$place3_from = $_POST['place3_from'];
		$place3_to = $_POST['place3_to'];
		
		

		// $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
		// try {
		//     //Server settings
		//     $mail->SMTPDebug = 2;                                 // Enable verbose debug output
		//     $mail->isSMTP();                                      // Set mailer to use SMTP
		//     $mail->Host = 'ssl://smtp.gmail.com:465';  // Specify main and backup SMTP servers
		//     $mail->SMTPAuth = true;                               // Enable SMTP authentication
		//     $mail->Username = 'xxxx@gmail.com';                 // SMTP username
		//     $mail->Password = 'xxxx';                           // SMTP password
		//     $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
		//     $mail->Port = 465;                                    // TCP port to connect to

		//     //Recipients
		//     $mail->setFrom('xxxxx@gmail.com', 'Mailer');
		// 	$mail->addAddress($email, 'Name Of the person');     // Add a recipient

		//     //Content
		//     $mail->isHTML(true);                                  // Set email format to HTML
		//     $mail->Subject = "Registration successfull $fullname";
		//     $mail->Body    = "Credentials To login into our site <br> Name: $fullname <br>Email : $email<br> Username: $username <br>Password: $password";

		//    	$mail->send();
		//    // echo 'Message has been sent';
		// } catch (Exception $e) {
		//    // echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
		// }	

			try {
				$stmt = $connect->prepare('INSERT INTO users (fullname, mobile, username, email, password,role,Age,material,quantity,city,state,truck_no,truck_cap,transporter_name,experience,place1_from,place1_to,place2_from,place2_to,place3_from,place3_to) VALUES ( :fullname, :mobile, :username, :email, :password,:role, :Age, :material, :quantity, :city, :state,:truck_no, :truck_cap, :transporter_name, :experience, :place1_from, :place1_to, :place2_from, :place2_to, :place3_from, :place3_to) ');
				$stmt->execute(array(
					':fullname' => $fullname,
					':username' => $username,
					':password' => md5($password),
					':email' => $email,
					':mobile' => $mobile,
					':role' => $role,
					':Age' => $Age,
					':material' => $material,
					':quantity' => $quantity,
					':city' => $city,
					':state' => $state,
					':truck_no' => $truck_no,
					':truck_cap' => $truck_cap,
					':transporter_name' => $transporter_name,
					':experience' => $experience,
					':place1_from' => $place1_from,
					':place1_to' => $place1_to,
					':place2_from' => $place2_from,
					':place2_to' => $place2_to,
					':place3_from' => $place3_from,
					':place3_to' => $place3_to,
					
					
					));
				header('Location: register.php?action=joined');
				exit;
			}
			catch(PDOException $e) {
				echo $e->getMessage();
			}
	}

	if(isset($_GET['action']) && $_GET['action'] == 'joined') {
		$errMsg = 'Registration successfull. Now you can login';
	}
?>

<?php include '../include/header.php';?>
	<!-- <nav class="navbar navbar-inverse">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <a class="navbar-brand" href="../index.php">WebSiteName</a>
	    </div>
	    <ul class="nav navbar-nav navbar-right">
			<li><a href="login.php">Login</a></li>
			<li><a href="register.php">Register</a></li>
	    </ul>
	  </div>
	</nav> -->
	<!-- Services -->
	<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:#212529;" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="../index.php">Home</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav text-uppercase ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
            <li class="nav-item">
              <!-- <a class="nav-link" href="register.php">Register</a> -->
            </li>
          </ul>
        </div>
      </div>
    </nav>
<!-- <section> --><br>
<section id="services">
	<div class="container">
		<div class="row">				
			  <div class="col-md-8 mx-auto">
			  	<div class="alert alert-info" role="alert">
			  		<?php
						if(isset($errMsg)){
							echo '<div style="color:#FF0000;text-align:center;font-size:17px;">'.$errMsg.'</div>';
						}
					?>
			  		<h2 class="text-center" >DEALERS / DRIVERS SIGN UP</h2>
				  	<form action="" method="post">
				  		<div class="row">
					  	    <div class="col-6">
						  	  <div class="form-group">
							    <label for="fullname">Full Name</label>
							    <input type="text" class="form-control" id="fullname" placeholder="Full Name" name="fullname" required>
							  </div>
							</div>
							<div class="col-6">
							  <div class="form-group">
							    <label for="username">User Name</label>
							    <input type="text" class="form-control" id="username" placeholder="User Name" name="username" required>
							  </div>
						    </div>
					   </div>
					   <div class="row">
					  	    <div class="col-6">
							  <div class="form-group">
							    <label for="mobile">Mobile</label>
							    <input type="text" class="form-control" pattern="^(\d{10})$" id="mobile" title="10 digit mobile number" placeholder="10 digit mobile number" name="mobile" required>
							  </div>
							 </div>
							<div class="col-6">					  
							  <div class="form-group">
							    <label for="email">Email</label>
							    <input type="email" class="form-control" id="email" placeholder="Email" name="email" required>
							  </div>
							 </div>
						</div>

					  <div class="form-group">
					    <label for="password">Password</label>
					    <input type="password" class="form-control" id="password" placeholder="Password" name="password" required>
					  </div>

					  <div class="form-group">
					    <label for="c_password">Confirm Password</label>
					    <input type="password" class="form-control" id="c_password" placeholder="Confirm Password" name="c_password" required>
					  </div>
					  <div class="form-group">
					    <label for="password">Role(Dealers/Drivers)</label>
					    <input type="role" class="form-control" id="role" placeholder="role" name="role" required>
					  </div>
					  
					  
					  
					  <div class="form-group">
					    <label for="Age">Age</label>
					    <input type="Age" class="form-control" id="Age" placeholder="Age" name="Age" required>
					  </div>
                       <div class="form-group">
					    <label for="material">Material(For Dealers)</label>
					    <input type="material" class="form-control" id="material" placeholder="material" name="material" >
					  </div>
                     <div class="form-group">
					    <label for="quantity">Quantity(For Dealers)</label>
					    <input type="quantity" class="form-control" id="quantity" placeholder="quantity" name="quantity" >
					  </div>
                     <div class="form-group">
					    <label for="city">City(For Dealers)</label>
					    <input type="city" class="form-control" id="city" placeholder="city" name="city" >
					  </div>
                     <div class="form-group">
					    <label for="state">State(For Dealers)</label>
					    <input type="state" class="form-control" id="state" placeholder="state" name="state" >
					  </div>
					  
					  <div class="form-group">
					    <h3 class="text-center" >DRIVERS SIGN UP</h3>
					    
					  </div>
					  
                     <div class="form-group">
					    <label for="truck_no">Truck Number</label>
					    <input type="truck_no" class="form-control" id="truck_no" placeholder="truck no" name="truck_no" >
					  </div>
                      <div class="form-group">
					    <label for="truck_cap">Truck Capacity</label>
					    <input type="truck_cap" class="form-control" id="truck_cap" placeholder="truck cap" name="truck_cap" >
					  </div>		
                     <div class="form-group">
					    <label for="transporter_name">Transporter Name</label>
					    <input type="transporter_name" class="form-control" id="transporter_name" placeholder="transporter name" name="transporter_name" >
					  </div>
					  
					  <div class="form-group">
					    <label for="Experience">Experience</label>
					    <input type="Experience" class="form-control" id="Experience" placeholder="Experience" name="Experience" >
					  </div>


                    <div class="form-group">
					    <label for="place1 from">Place1 From</label>
					    <input type="place1_from" class="form-control" id="place1_from" placeholder="place1 from" name="place1_from " >
					  </div>
				
				
                    <div class ="form-group">
					    <label for="place1 to">Place1 To</label>
					    <input type="place1_to" class="form-control" id="place1_to" placeholder="place1 to" name="place1_to">
					  </div>
					  
                    <div class="form-group">
					    <label for="place2 from">Place2 From</label>
					    <input type="place2_from" class="form-control" id="place2_from" placeholder="place2 from" name="place2_from" >
					  </div>
					  
                    <div class="form-group">
					    <label for="place2 to">Place2 To</label>
					    <input type="place2_to" class="form-control" id="place2_to" placeholder="place2 to" name="place2_to" >
					  </div>
					  
                    <div class="form-group">
					    <label for="place3 from">Place3 From</label>
					    <input type="place3_from" class="form-control" id="place3_from" placeholder="place3 from" name="place3_from" >
					  </div>
					  
					  
                    <div class="form-group">
					    <label for="place3 to">Place3 To</label>
					    <input type="place3_to" class="form-control" id="place3_to" placeholder="place3 to" name="place3_to" >
					  </div>


					  <button type="submit" class="btn btn-success" name='register' value="register">Submit</button>
					</form>				
				</div>
			</div>
		</div>
	</div>
	</section>
<!-- </section> -->

<?php include '../include/footer.php';?>
