
<?php
	require '../config/config.php';
	if(empty($_SESSION['username']))
		header('Location: login.php');
	?>
<html>


<?php include '../include/header.php';?>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color:#212529;" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="../index.php">Home</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		</button>	
		</div>
		
	</nav>
<head><title>ABOUT US</title></head>
<section id="services">	
<b> ABOUT US </b>
	
<body>
	<div align="center">
		<div style=" border: solid 2px #006D9C; " align="left">
</body>

<h1 style="color:tomato">WELCOME TO Dealers and drivers MS Website 2022</h1>

<h3>A Dealers and drivers MS Website 2022 is a business entity that deals with web application where dealers can book drivers through the application
for transporting their goods.</h3>

<p>
<h4 style="color:blue">CONTACT US :</h4> 
<h5>EMAIL : geethika02@gmail.com</h5>
</P>
<p>
<p>
<h6>2022 Dealers and drivers MS Website 2022.</h6>
</p>
</p>
</section>
		
</html>
<?php include '../include/footer.php';?>